# My First Automation Project

This project is a simple Python script that simulates automated deployment steps.

## Features
- Simulates app deployment
- Uses system commands
- Easy to expand

## Run the Script
```bash
python deploy.py
```

## Author
SINAM BANSAL
