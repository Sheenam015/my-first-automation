import os

def deploy_app():
    print("Starting deployment...")
    # Simulated steps
    os.system("echo Pulling latest code from GitHub...")
    os.system("echo Installing dependencies...")
    os.system("echo Starting the application...")
    print("Deployment completed successfully!")

if __name__ == "__main__":
    deploy_app()
